fetch("https://restcountries.com/v3.1/name/indonesia").then((response) =>
  console.log(response)
);
